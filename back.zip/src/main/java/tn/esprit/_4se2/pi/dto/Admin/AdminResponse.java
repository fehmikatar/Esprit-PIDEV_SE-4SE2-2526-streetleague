package tn.esprit._4se2.pi.dto.Admin;

import lombok.*;
import lombok.experimental.FieldDefaults;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AdminResponse {
    Long id;
    String firstName;
    String lastName;
    String email;
    String adminRole;
    String department;
    LocalDateTime createdAt;
    Boolean isActive;
}