package tn.esprit._4se2.pi.restcontrollers;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import tn.esprit._4se2.pi.dto.Performance.PerformanceRequest;
import tn.esprit._4se2.pi.dto.Performance.PerformanceResponse;
import tn.esprit._4se2.pi.services.Performance.PerformanceService;

import java.util.List;

@RestController
@RequestMapping("/api/performances")
@RequiredArgsConstructor
public class PerformanceController {

    private final PerformanceService performanceService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public PerformanceResponse createPerformance(@RequestBody PerformanceRequest request) {
        return performanceService.createPerformance(request);
    }

    @GetMapping
    public List<PerformanceResponse> getAllPerformances() {
        return performanceService.getAllPerformances();
    }

    @GetMapping("/{id}")
    public PerformanceResponse getPerformanceById(@PathVariable Long id) {
        return performanceService.getPerformanceById(id);
    }

    @PutMapping("/{id}")
    public PerformanceResponse updatePerformance(@PathVariable Long id, @RequestBody PerformanceRequest request) {
        return performanceService.updatePerformance(id, request);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deletePerformance(@PathVariable Long id) {
        performanceService.deletePerformance(id);
    }
}